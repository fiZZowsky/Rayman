@mainpage Rayman 
@section mainpageRayman1  Gra Rayman/Mario Bros
 <i>Gra platformowa wykonana w stylu gier Rayman i Mario Bros przy użyciu języka C/C++  oraz biblioteki Direct2D.<br>

Rayman - seria platformowych gier komputerowych, stworzona przez Michela Ancela i wydana przez francuskie studio Ubisoft. Głównym bohaterem serii jest tytułowy stworek Rayman, a wszystkie jego przygody dzieją się w świecie zwanym Rozdroże Marzeń. Pierwsza gra z serii miała swoją premierę w 1995 roku – była to gra platformowa w grafice 2D.<br>

Mario Bros - komputerowa gra platformowa stworzona przez Nintendo i wydana w 1983 jako gra arcade. W grze mogą uczestniczyć 1 lub 2 osoby (w niektórych wersjach do 4). Gracz pierwszy steruje Mario, natomiast drugi Luigim.<br>  

Direct2D – wysokopoziomowe API do programowania aplikacji używających grafiki dwuwymiarowej i wektorowej. Jest dostępny jako część DirectX od wersji 11. Zastąpił zdeprecjonowany interfejs DirectDraw. Direct2D pozwala na sprzętową akcelerację grafiki 2D poprzez kartę graficzną, oferując wysoką jakość i szybkość.<br></i>

@section mainpageRayman2 Twórcy
<span style="color: #5dd811; font-family: Consolas; font-size:20px">Równicki Piotr</span><br> 
<span style="color: #5dd811; font-family: Consolas; font-size:20px">Sikora Wiktor</span><br> 


