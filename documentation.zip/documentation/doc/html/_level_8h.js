var _level_8h =
[
    [ "Level", "class_level.html", "class_level" ],
    [ "LEVEL_HEIGHT", "_level_8h.html#a16621561d55e77faa59fbfdae692916f", null ],
    [ "LEVEL_WIDTH", "_level_8h.html#a219cc98394ab36a78470c0627c4f8464", null ],
    [ "TILE_WIDTH", "_level_8h.html#a76108891dc4352082a676f2978ee446d", null ]
];