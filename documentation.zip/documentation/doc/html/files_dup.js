var files_dup =
[
    [ "dock_page", "dir_694ffb420ce62475cc92197444302cd4.html", null ],
    [ "App.cpp", "_app_8cpp.html", "_app_8cpp" ],
    [ "App.h", "_app_8h.html", "_app_8h" ],
    [ "Character.cpp", "_character_8cpp.html", null ],
    [ "Character.h", "_character_8h.html", "_character_8h" ],
    [ "CollisionDistances.h", "_collision_distances_8h.html", [
      [ "CollisionDistances", "struct_collision_distances.html", "struct_collision_distances" ]
    ] ],
    [ "Enemy.cpp", "_enemy_8cpp.html", null ],
    [ "Enemy.h", "_enemy_8h.html", "_enemy_8h" ],
    [ "Engine.cpp", "_engine_8cpp.html", null ],
    [ "Engine.h", "_engine_8h.html", [
      [ "Engine", "class_engine.html", "class_engine" ]
    ] ],
    [ "EngineBase.cpp", "_engine_base_8cpp.html", null ],
    [ "EngineBase.h", "_engine_base_8h.html", [
      [ "EngineBase", "class_engine_base.html", "class_engine_base" ]
    ] ],
    [ "framework.h", "framework_8h.html", "framework_8h" ],
    [ "GameObjectBase.cpp", "_game_object_base_8cpp.html", null ],
    [ "GameObjectBase.h", "_game_object_base_8h.html", [
      [ "GameObjectBase", "class_game_object_base.html", "class_game_object_base" ]
    ] ],
    [ "HUD.cpp", "_h_u_d_8cpp.html", null ],
    [ "HUD.h", "_h_u_d_8h.html", [
      [ "HUD", "class_h_u_d.html", "class_h_u_d" ]
    ] ],
    [ "Level.cpp", "_level_8cpp.html", null ],
    [ "Level.h", "_level_8h.html", "_level_8h" ],
    [ "Point2D.h", "_point2_d_8h.html", [
      [ "Point2D", "struct_point2_d.html", "struct_point2_d" ]
    ] ],
    [ "Resource.h", "_resource_8h.html", "_resource_8h" ],
    [ "Settings.h", "_settings_8h.html", "_settings_8h" ],
    [ "targetver.h", "targetver_8h.html", null ]
];