var _app_8cpp =
[
    [ "D2D_BACKGROUND_COLOR", "_app_8cpp.html#a4f2fa81c5afbe09d47e553ef158e30d2", null ],
    [ "wWinMain", "_app_8cpp.html#a1e683c5a19c00d05cd803e46b805e339", null ]
];