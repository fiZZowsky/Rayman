var _resource_8h =
[
    [ "IDC_GAME", "_resource_8h.html#a2bba3be7fb1e66473d88b6a3624ab0a9", null ],
    [ "IDC_MYICON", "_resource_8h.html#abb326bd165140b31acf04b893ef655ca", null ],
    [ "IDC_STATIC", "_resource_8h.html#ac93033490bc8943cfc82ec3b40e5cd74", null ],
    [ "IDD_ABOUTBOX", "_resource_8h.html#a77a06326b569136edbb6c766bc98c33c", null ],
    [ "IDD_GAME_DIALOG", "_resource_8h.html#aa974c4cf2a84d50c7fac53504aa934e9", null ],
    [ "IDI_GAME", "_resource_8h.html#abf4da31825fb2f3e2d1645b4c38e3f44", null ],
    [ "IDI_SMALL", "_resource_8h.html#a861a8cb71616b4615a5823bcf4bff6e3", null ],
    [ "IDM_ABOUT", "_resource_8h.html#a589e0105bc3e8681893dbf51210ceeec", null ],
    [ "IDM_EXIT", "_resource_8h.html#a79aeed168a959b22b32169e25f8c1f4d", null ],
    [ "IDR_MAINFRAME", "_resource_8h.html#a9772c84d39896ad00b9aeb34b15d324d", null ],
    [ "IDS_APP_TITLE", "_resource_8h.html#a636c9aea2a8d16b73e43df39b3e0e7bd", null ]
];