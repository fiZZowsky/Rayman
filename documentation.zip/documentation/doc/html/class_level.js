var class_level =
[
    [ "Level", "class_level.html#a7a696c928ca5d5354db6e50e46d0f67d", null ],
    [ "CharacterCollides", "class_level.html#ad45cf095bc5c87509c8299b440423f80", null ],
    [ "Draw", "class_level.html#aae261de39883c5eabc60a79148ee8c5a", null ],
    [ "LevelExit", "class_level.html#ac033713028e5eddf06bd43f25fa61079", null ],
    [ "PickUpCollectibles", "class_level.html#a797552cbd208b8b4e6c3ed4fef56b847", null ]
];