var searchData=
[
  ['v_5fsync_104',['V_SYNC',['../_settings_8h.html#a327e2d7d7c769c7178fb0d589822e595',1,'Settings.h']]]
];
