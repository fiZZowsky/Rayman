var searchData=
[
  ['resolution_5fx_223',['RESOLUTION_X',['../_settings_8h.html#a9e792853a0cf077a38db0145264e7f18',1,'Settings.h']]],
  ['resolution_5fy_224',['RESOLUTION_Y',['../_settings_8h.html#a1a1e0355c7bcd3b753d6bb613f47a9a3',1,'Settings.h']]]
];
