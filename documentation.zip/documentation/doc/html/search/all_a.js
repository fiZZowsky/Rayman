var searchData=
[
  ['jump_61',['Jump',['../class_character.html#aa06b0a7d759d483c31eb578f6a363446',1,'Character']]]
];
