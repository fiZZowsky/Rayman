var searchData=
[
  ['idc_5fgame_47',['IDC_GAME',['../_resource_8h.html#a2bba3be7fb1e66473d88b6a3624ab0a9',1,'Resource.h']]],
  ['idc_5fmyicon_48',['IDC_MYICON',['../_resource_8h.html#abb326bd165140b31acf04b893ef655ca',1,'Resource.h']]],
  ['idc_5fstatic_49',['IDC_STATIC',['../_resource_8h.html#ac93033490bc8943cfc82ec3b40e5cd74',1,'Resource.h']]],
  ['idd_5faboutbox_50',['IDD_ABOUTBOX',['../_resource_8h.html#a77a06326b569136edbb6c766bc98c33c',1,'Resource.h']]],
  ['idd_5fgame_5fdialog_51',['IDD_GAME_DIALOG',['../_resource_8h.html#aa974c4cf2a84d50c7fac53504aa934e9',1,'Resource.h']]],
  ['idi_5fgame_52',['IDI_GAME',['../_resource_8h.html#abf4da31825fb2f3e2d1645b4c38e3f44',1,'Resource.h']]],
  ['idi_5fsmall_53',['IDI_SMALL',['../_resource_8h.html#a861a8cb71616b4615a5823bcf4bff6e3',1,'Resource.h']]],
  ['idm_5fabout_54',['IDM_ABOUT',['../_resource_8h.html#a589e0105bc3e8681893dbf51210ceeec',1,'Resource.h']]],
  ['idm_5fexit_55',['IDM_EXIT',['../_resource_8h.html#a79aeed168a959b22b32169e25f8c1f4d',1,'Resource.h']]],
  ['idr_5fmainframe_56',['IDR_MAINFRAME',['../_resource_8h.html#a9772c84d39896ad00b9aeb34b15d324d',1,'Resource.h']]],
  ['ids_5fapp_5ftitle_57',['IDS_APP_TITLE',['../_resource_8h.html#a636c9aea2a8d16b73e43df39b3e0e7bd',1,'Resource.h']]],
  ['initialize_58',['Initialize',['../class_main_app.html#a43ab64552bbc99093a3240ba9d3e6f30',1,'MainApp']]],
  ['initialized2d_59',['InitializeD2D',['../class_engine_base.html#a58ac21b4f3fda8e1b5282405292dc2c7',1,'EngineBase']]],
  ['isdead_60',['IsDead',['../class_character.html#ab85af93906a33ef841efec79e082fa42',1,'Character']]]
];
