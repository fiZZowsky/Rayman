var searchData=
[
  ['saferelease_181',['SafeRelease',['../framework_8h.html#a5372b6d9be095d35b1ce2b8e6cbcb982',1,'framework.h']]],
  ['stopfalling_182',['StopFalling',['../class_character.html#a2765a87ff1849e9d0e98464d7b70d9fd',1,'Character']]],
  ['stopmovingleft_183',['StopMovingLeft',['../class_character.html#a41a75e2c130e201d29ab2e15a73c4c7c',1,'Character']]],
  ['stopmovingright_184',['StopMovingRight',['../class_character.html#abd53e486b0a3bd7397799bb15e4f1ebf',1,'Character']]]
];
