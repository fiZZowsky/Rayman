var searchData=
[
  ['level_5fheight_221',['LEVEL_HEIGHT',['../_level_8h.html#a16621561d55e77faa59fbfdae692916f',1,'Level.h']]],
  ['level_5fwidth_222',['LEVEL_WIDTH',['../_level_8h.html#a219cc98394ab36a78470c0627c4f8464',1,'Level.h']]]
];
