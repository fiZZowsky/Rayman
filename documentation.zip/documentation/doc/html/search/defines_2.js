var searchData=
[
  ['d2d_5fbackground_5fcolor_206',['D2D_BACKGROUND_COLOR',['../_app_8cpp.html#a4f2fa81c5afbe09d47e553ef158e30d2',1,'Settings.h']]]
];
