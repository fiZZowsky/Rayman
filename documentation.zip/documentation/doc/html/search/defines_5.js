var searchData=
[
  ['idc_5fgame_210',['IDC_GAME',['../_resource_8h.html#a2bba3be7fb1e66473d88b6a3624ab0a9',1,'Resource.h']]],
  ['idc_5fmyicon_211',['IDC_MYICON',['../_resource_8h.html#abb326bd165140b31acf04b893ef655ca',1,'Resource.h']]],
  ['idc_5fstatic_212',['IDC_STATIC',['../_resource_8h.html#ac93033490bc8943cfc82ec3b40e5cd74',1,'Resource.h']]],
  ['idd_5faboutbox_213',['IDD_ABOUTBOX',['../_resource_8h.html#a77a06326b569136edbb6c766bc98c33c',1,'Resource.h']]],
  ['idd_5fgame_5fdialog_214',['IDD_GAME_DIALOG',['../_resource_8h.html#aa974c4cf2a84d50c7fac53504aa934e9',1,'Resource.h']]],
  ['idi_5fgame_215',['IDI_GAME',['../_resource_8h.html#abf4da31825fb2f3e2d1645b4c38e3f44',1,'Resource.h']]],
  ['idi_5fsmall_216',['IDI_SMALL',['../_resource_8h.html#a861a8cb71616b4615a5823bcf4bff6e3',1,'Resource.h']]],
  ['idm_5fabout_217',['IDM_ABOUT',['../_resource_8h.html#a589e0105bc3e8681893dbf51210ceeec',1,'Resource.h']]],
  ['idm_5fexit_218',['IDM_EXIT',['../_resource_8h.html#a79aeed168a959b22b32169e25f8c1f4d',1,'Resource.h']]],
  ['idr_5fmainframe_219',['IDR_MAINFRAME',['../_resource_8h.html#a9772c84d39896ad00b9aeb34b15d324d',1,'Resource.h']]],
  ['ids_5fapp_5ftitle_220',['IDS_APP_TITLE',['../_resource_8h.html#a636c9aea2a8d16b73e43df39b3e0e7bd',1,'Resource.h']]]
];
