var _settings_8h =
[
    [ "RESOLUTION_X", "_settings_8h.html#a9e792853a0cf077a38db0145264e7f18", null ],
    [ "RESOLUTION_Y", "_settings_8h.html#a1a1e0355c7bcd3b753d6bb613f47a9a3", null ],
    [ "V_SYNC", "_settings_8h.html#a327e2d7d7c769c7178fb0d589822e595", null ]
];