var hierarchy =
[
    [ "CollisionDistances", "struct_collision_distances.html", null ],
    [ "EngineBase", "class_engine_base.html", [
      [ "Engine", "class_engine.html", null ]
    ] ],
    [ "GameObjectBase", "class_game_object_base.html", [
      [ "Character", "class_character.html", null ],
      [ "Enemy", "class_enemy.html", null ],
      [ "HUD", "class_h_u_d.html", null ],
      [ "Level", "class_level.html", null ]
    ] ],
    [ "MainApp", "class_main_app.html", null ],
    [ "Point2D", "struct_point2_d.html", null ]
];