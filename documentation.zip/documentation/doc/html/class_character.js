var class_character =
[
    [ "Character", "class_character.html#adc27bdd255876169bad2ed0bae0cffb5", null ],
    [ "BounceTop", "class_character.html#ae475d744bce05e280f3b2d59efd81b59", null ],
    [ "Die", "class_character.html#ad4cf75aee602249dff4bdb61f20eb5f2", null ],
    [ "Draw", "class_character.html#a2a3960ed61e12aff7905abba2dcd1c43", null ],
    [ "IsDead", "class_character.html#ab85af93906a33ef841efec79e082fa42", null ],
    [ "Jump", "class_character.html#aa06b0a7d759d483c31eb578f6a363446", null ],
    [ "Logic", "class_character.html#a7a6ceeab67dd53cd584906f61b4ccaab", null ],
    [ "Reset", "class_character.html#a6c1fa20d22b5ea6edc4dbd6ca9496411", null ],
    [ "StopFalling", "class_character.html#a2765a87ff1849e9d0e98464d7b70d9fd", null ],
    [ "StopMovingLeft", "class_character.html#a41a75e2c130e201d29ab2e15a73c4c7c", null ],
    [ "StopMovingRight", "class_character.html#abd53e486b0a3bd7397799bb15e4f1ebf", null ],
    [ "GoesLeft", "class_character.html#a9f66c162bef39ce7cf2c17dc6ee2140b", null ],
    [ "GoesRight", "class_character.html#a3cf90af2e7bab9b205b7af3777ca16cd", null ]
];