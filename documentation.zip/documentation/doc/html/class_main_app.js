var class_main_app =
[
    [ "MainApp", "class_main_app.html#a62488418e2bc66492d3d5bcc836a7103", null ],
    [ "~MainApp", "class_main_app.html#a1da72f01017840ab6165e33b76cc8482", null ],
    [ "Initialize", "class_main_app.html#a43ab64552bbc99093a3240ba9d3e6f30", null ],
    [ "RunMessageLoop", "class_main_app.html#af1f3cdbd74af3cdaa7cc15b8fe5f45e6", null ]
];