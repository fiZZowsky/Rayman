var framework_8h =
[
    [ "WIN32_LEAN_AND_MEAN", "framework_8h.html#ac7bef5d85e3dcd73eef56ad39ffc84a9", null ],
    [ "SafeRelease", "framework_8h.html#a5372b6d9be095d35b1ce2b8e6cbcb982", null ]
];