var struct_collision_distances =
[
    [ "keepLargest", "struct_collision_distances.html#a16f6dba476fb31909eaa8e4cb8cda4da", null ],
    [ "keepSmallest", "struct_collision_distances.html#a95fe9b84b986e20567601a062b2e225d", null ],
    [ "bottom", "struct_collision_distances.html#ae38cad2b4b8b10357e4ffdfe8d9afb1a", null ],
    [ "left", "struct_collision_distances.html#a138e06923d3edfbec545c1e265436ca8", null ],
    [ "right", "struct_collision_distances.html#a36bf19b02efa25f8d33997e0d756e6c2", null ],
    [ "top", "struct_collision_distances.html#a29e0cb3e7875ed6fab75f3e520cefb33", null ]
];