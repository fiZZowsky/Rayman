var class_h_u_d =
[
    [ "HUD", "class_h_u_d.html#a568b8ee1591f9ba3ed36ae05966f6b56", null ],
    [ "AddCoins", "class_h_u_d.html#abdc50d2252f1f49172d8203e158e9e32", null ],
    [ "Draw", "class_h_u_d.html#afd7b8ae308fb3c5d5c1f8d50f353c713", null ],
    [ "FinishedLevel", "class_h_u_d.html#a231046d06058f994828456d9520e3999", null ],
    [ "HasLives", "class_h_u_d.html#ab321f7a4ffa73e2e2b85b88a95538d35", null ],
    [ "RemoveLife", "class_h_u_d.html#a1bb07f46be3b72dd5ba64eed813a3195", null ]
];