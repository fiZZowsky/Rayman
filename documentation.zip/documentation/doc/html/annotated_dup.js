var annotated_dup =
[
    [ "Character", "class_character.html", "class_character" ],
    [ "CollisionDistances", "struct_collision_distances.html", "struct_collision_distances" ],
    [ "Enemy", "class_enemy.html", "class_enemy" ],
    [ "Engine", "class_engine.html", "class_engine" ],
    [ "EngineBase", "class_engine_base.html", "class_engine_base" ],
    [ "GameObjectBase", "class_game_object_base.html", "class_game_object_base" ],
    [ "HUD", "class_h_u_d.html", "class_h_u_d" ],
    [ "Level", "class_level.html", "class_level" ],
    [ "MainApp", "class_main_app.html", "class_main_app" ],
    [ "Point2D", "struct_point2_d.html", "struct_point2_d" ]
];