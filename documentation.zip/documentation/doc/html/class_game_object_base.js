var class_game_object_base =
[
    [ "Draw", "class_game_object_base.html#ae4df53443a7d3fba021980070b56d068", null ],
    [ "GetPosition", "class_game_object_base.html#a355ba662a9630ce8a542a7c940f239b6", null ],
    [ "Logic", "class_game_object_base.html#acf0082831f1d1dff2d16c44282929b38", null ],
    [ "engine", "class_game_object_base.html#adef1b4a1d133efac87f9bef37477cfbd", null ],
    [ "position", "class_game_object_base.html#a55230f11d115d2e7ef8c22c07eaab528", null ]
];