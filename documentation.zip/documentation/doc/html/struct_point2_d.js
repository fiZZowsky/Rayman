var struct_point2_d =
[
    [ "x", "struct_point2_d.html#a42fcad8b63853b1136e6207ace6d555e", null ],
    [ "y", "struct_point2_d.html#a55747be726950fdcba27c1ad032bfdf1", null ]
];